// index.js - フィルターモジュールのエクスポート

import AnswerFilter from "./answer-filter.js";

export { AnswerFilter };
